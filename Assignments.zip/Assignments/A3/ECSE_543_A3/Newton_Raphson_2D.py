# ESCE 543: Numerical Methods, Assignment 3, Q3
# Antonia Butler 260613935

# Newton-Raphson method for non-linear vector equations.
import math
import numpy as np

# helpers:
# vector dot product:
def dot(A, B):
    n = len(A)  # (= len(B))
    dot = 0
    for i in range(n):
        dot += A[i]*B[i]
    return dot

# matrix dot product:
def M_dot(A, B):
    # A is n x m, B is p X q
    n = len(A)      # A rows
    m = len(A[0])   # A cols
    p = len(B)      # B rows
    q = len(B[0])   # B cols

    # m should = p
    if m != p:
        print("Matrices for dot product have invalid dimensions")
        return

    # result will be n x q
    dot_product = [[0] * q for i in range(n)]
    B_t = trans(B)      # transpose so that I can use the dot product method above on columns
    for i in range(n):
        for j in range(q):
            dot_product[i][j] = dot(A[i], B_t[j])

    return dot_product

# transpose of a matrix:
def trans(matrixA):
    n = len(matrixA)
    m = len(matrixA[0])
    AT = np.array([[0.0] * n for j in range(m)])
    for i in range(m):
        for j in range(n):
            AT[i][j] = matrixA[j][i]
    return AT


# Newton-Raphson solver for 2-diode circuit:
def N_R(v, E, R, Isa, Isb, K):
    # v = [v_a, v_b]^T
    va = v[0][0]
    vb = v[1][0]

    # f(v) = [f1(v), f2(v)]^T = [0, 0]^T
    f1 = va - E + R*Isa*(math.exp(K*(va-vb))-1)
    f2 = Isa*(math.exp(K*(va-vb))-1) - Isb*(math.exp(K*vb)-1)
    f = [[f1], [f2]]

    # Jacobian:
    J_11 = 1 + R*Isa*K*(math.exp(K*(va-vb)))
    J_12 = -R*Isa*K*(math.exp(K*(va-vb)))
    J_21 = Isa*K*(math.exp(K*(va-vb)))
    J_22 = -Isa*K*(math.exp(K*(va-vb))) - Isb*K*(math.exp(K*vb))

    # J^(-1)
    # use determinant to calculate...
    detJ = J_11*J_22 - J_21*J_12

    inv_J_11 = 1/detJ*J_22
    inv_J_12 = -1/detJ*J_12
    inv_J_21 = -1/detJ*J_21
    inv_J_22 = 1/detJ*J_11

    inv_J = [[inv_J_11, inv_J_12], [inv_J_21, inv_J_22]]

    # v (k + 1) = v(k) - J^-1 * f(k)
    JinvF = M_dot(inv_J, f)

    v[0][0] = v[0][0] - JinvF[0][0]
    v[1][0] = v[1][0] - JinvF[1][0]

    if abs(f[0][0]) > abs(f[1][0]):
        err = f[0][0]
    else:
        err = f[1][0]

    return v, err


# Starting solution: v = [0, 0]
v = [[0], [0]]
# circuit params:
R = 500; E = 0.22; Isa = 0.0000006; Isb = 0.0000012; K = 40  # 1/kT/q = q/kT

accurate = False
itr = 0
while not accurate:
    itr += 1
    v_new, err = N_R(v, E, R, Isa, Isb, K)

    print('v_new: ', v_new, 'err: ', err)

    if abs(err) > 0.0001:
        v = v_new
    else:
        accurate = True

print('num iterations = ', itr)
