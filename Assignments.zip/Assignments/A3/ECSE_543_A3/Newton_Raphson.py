# ESCE 543: Numerical Methods, Assignment 3, Q2(b)
# Antonia Butler 260613935

# Newton-Raphson method for non-linear equations.
import math
import numpy as np

# helpers:
# vector dot product:
def dot(A, B):
    n = len(A)  # (= len(B))
    dot = 0
    for i in range(n):
        dot += A[i]*B[i]
    return dot

# matrix dot product:
def M_dot(A, B):
    # A is n x m, B is p X q
    n = len(A)      # A rows
    m = len(A[0])   # A cols
    p = len(B)      # B rows
    q = len(B[0])   # B cols

    # m should = p
    if m != p:
        print("Matrices for dot product have invalid dimensions")
        return

    # result will be n x q
    dot_product = [[0] * q for i in range(n)]
    B_t = trans(B)      # transpose so that I can use the dot product method above on columns
    for i in range(n):
        for j in range(q):
            dot_product[i][j] = dot(A[i], B_t[j])

    return dot_product

# transpose of a matrix:
def trans(matrixA):
    n = len(matrixA)
    m = len(matrixA[0])
    AT = np.array([[0.0] * n for j in range(m)])
    for i in range(m):
        for j in range(n):
            AT[i][j] = matrixA[j][i]
    return AT

def lin_interpolate(B, H):
    # number of intervals = number of data points -1:
    N = len(B) -1
    # u = B/H(B)
    u = [0]*N
    for i in range(N):
        # u over each interval = slope: delta(y)/delta(x):
        u[i] = (B[i+1] - B[i])/(H[i+1] - H[i])

    return u


# Newton-Raphson solver for Magnetic circuit:
def N_R(flux, M, A, u0, u_c, Lc, Lg):

    # f(Phi) = M - Rg*Phi - Lc* H(Phi)
    Rg = Lg/(A*u0)      # gap reluctance
    H_phi = flux/(A*u_c)
    f = M - Rg*flux - Lc*H_phi

    #df/dPhi
    f_prime = -Rg - Lc/(A*u_c)

    # Phi (k + 1) = Phi(k) - f(k)/f'(k)
    flux_new = flux - f/(f_prime)

    return flux_new, f


# Successive Substitution solver for Magnetic circuit:
# (same as N-R above, except f' = 1 (slope -1))
def SS(flux, M, A, u0, u_c, Lc, Lg):

    # f(Phi) = M - Rg*Phi - Lc* H(Phi)
    Rg = Lg/(A*u0)      # gap reluctance
    H_phi = flux/(A*u_c)
    f = (M - Rg*flux - Lc*H_phi)*1e-10

    # Phi (k + 1) = Phi(k) - f(k)
    flux_new = flux - f

    return flux_new, f


B = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9]
H = [0.0, 14.7, 36.5, 71.7, 121.4, 197.4, 256.4, 348.7, 540.6, 1062.8, 2318.0, 4781.9, 8687.4, 13924.3, 22650.2]

# Starting solution: Phi = 0
flux =0

# circuit params:
M = 1000*8; A = 0.0001; u0 = 4e-7*math.pi; Lc = 0.3; La = 0.005
u = lin_interpolate(B, H)
print ('u: ', u)

flux_0, f_0 = N_R(0, M, A, u0, u[0], Lc, La)

u_c = 0    # initialize

accurate = False
itr = 0
err = 1
while not accurate:
    itr += 1
    # relate flux to B to determine which value to use for u_c:
    # flux = B* A
    for i in range(len(B)-1):
        # B and H may lie outside the given range:
        if flux/A >= B[-1]:
            u_c = u[-1]
            break
        elif (flux/A >= B[i]) and (flux/A < B[i+1]):
            u_c = u[i]
            break

    flux_new, f_new = N_R(flux, M, A, u0, u_c, Lc, La)

    err = f_new/f_0

    if abs(err) > 1e-6:
        flux = flux_new
    else:
        accurate = True

    print('flux: ', flux, 'err: ', err)

print('num iterations = ', itr, '\nfinal flux = ', flux, '[Wb]')

