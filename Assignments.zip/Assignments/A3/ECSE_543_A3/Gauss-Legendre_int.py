# ESCE 543: Numerical Methods, Assignment 3, Q4
# Antonia Butler 260613935

# Numerical Integration with 1-point Gauss-Legendre method

# method to calculate approximate integral of function f over interval [x_start, x_stop], with N sub-intervals
# Using one-point Gauss-Legendre, with evenly spaced segments:
import math

def gl_one_pt(x_start, x_stop, N, f):
    # sub-interval length:
    h = (x_stop - x_start)/ N

    # over each sub-interval
    weights = [0]*N
    abscissas = [0]*N

    for i in range(N):
        # for 1-pt G-L, weights are equal to sub-interval length:
        weights[i] = h

        # left bound:
        xl = x_start + i*h

        # abscissa points:
        abscissas[i] = xl + h/2

    # result over each sub-interval: w_i * f (x_i))
    integral = sum((weights[i]*f(abscissas[i])) for i in range(N))

    return integral

def gl_uneven(x_start, x_stop, N, f):
    # regular sub-interval length:
    h = (x_stop - x_start) / N

    # over each sub-interval
    weights = [0] * N
    abscissas = [0] * N

    xl = 0

    for i in range(N):
        # varying sub-interval widths:
        # decrease interval width for 1st half of intervals:
        if i < N/2:
            h_var = h - h/5*(4 - i)
        # increase interval width for 2nd half of intervals:
        elif i >= N/2:
            h_var = h + h/5*(i - 5)

        # for 1-pt G-L, weights are equal to sub-interval length:
        weights[i] = h_var

        # abscissa points:
        abscissas[i] = xl + weights[i]/2

        # new left bound:
        xl = xl + weights[i]

    # result over each sub-interval: w_i * f (x_i))
    integral = sum((weights[i] * f(abscissas[i])) for i in range(N))

    return integral


x_start = 0
x_stop = 1
function1 = lambda x: math.cos(x)
function2 = lambda y: math.log(y, math.e)

actual1 = math.sin(x_stop) - math.sin(x_start)
actual2 = -1

N = 10
int = gl_one_pt(x_start, x_stop, N, function2)
error_ev = -1 - int
int_eneven = gl_uneven(x_start, x_stop, N, function2)
error_unev = -1 - int_eneven
print("Result for equally spaced intervals:")
print('N: ',N, ', result: ', int, ', error: ', error_ev)
print("\nResult for unequally spaced intervals:")
print('N: ', N, ', result: ', int_eneven, ', error: ', error_unev)


print('function: ln(x), interval: [0,1]')
for N in range(10, 201):
    int = gl_one_pt(x_start, x_stop, N, function2)
    error = actual2 - int
    print('N: ', N, ', result: ', int, ', error: ', error)


