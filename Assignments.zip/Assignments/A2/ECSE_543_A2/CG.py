# ESCE 543: Numerical Methods, Assignment 2, Q3
# Antonia Butler 260613935

# (Un-preconditioned) Conjugate Gradient Method

import numpy as np
import FEGridGenerator as fe
import scipy.linalg   # SciPy Linear Algebra Library

# helper functions:
# vector dot product:
def dot(A, B):
    n = len(A)  # (= len(B))
    dot = 0
    for i in range(n):
        dot += A[i]*B[i]
    return dot

# matrix dot product:
def M_dot(A, B):
    # A is n x m, B is p X q
    n = len(A)      # A rows
    m = len(A[0])   # A cols
    p = len(B)      # B rows
    q = len(B[0])   # B cols

    # m should = p
    if m != p:
        print("Matrices for dot product have invalid dimensions")
        return

    # result will be n x q
    dot_product = [[0] * q for i in range(n)]
    B_t = trans(B)      # transpose so that I can use the dot product method above on columns
    for i in range(n):
        for j in range(q):
            dot_product[i][j] = dot(A[i], B_t[j])

    return dot_product

# transpose of a matrix:
def trans(matrixA):
    n = len(matrixA)
    m = len(matrixA[0])
    AT = np.array([[0.0] * n for j in range(m)])
    for i in range(m):
        for j in range(n):
            AT[i][j] = matrixA[j][i]
    return AT

# conj gradient method:
def CG(A, b, n):

    # set initial values
    x = [[0.0]*1 for i in range (n)]
    # residual at each node
    r = [[0.0]*1 for i in range (n)]
    for i in range(n):
        r[i][0] = b[i][0] - M_dot(A, x)[i][0]
    # direction vector:
    p = r

    # iteration variable:
    k = 0

    # Iterate until residual is small enough.
    # Solution is obtained after at most n iterations for CG:
    while k <= n:
        # generate infinity norm and 2-norm for each iteration:
        if k == 0:
            inf_norm = []
            two_norm = []

        inf = 0
        for i in range(n):
            if r[i][0] > inf:
                inf = r[i][0]
        inf_norm.append(inf)

        two_norm.append(np.linalg.norm(r))

        Y = M_dot(M_dot(trans(p), A), p)        # (p^T*A*p): expensive matrix multiplication... save result to reuse

        # alpha = p^T/(p^T*A*p)
        alpha = M_dot(trans(p), r)[0][0] / Y[0][0]

        # x' = x + alpha*A
        x_prime = [[0]*1 for i in range(n)]
        for i in range(n):
            x_prime[i][0] = x[i][0] + alpha*p[i][0]
        # print('x = ', x_prime)

        # r' = b - Ax'
        r_prime = [[0]*1 for i in range(n)]
        for i in range(n):
            r_prime[i][0] = b[i][0] - M_dot(A, x_prime)[i][0]

        # B = - p^T*A*r' / (p^T*A*p)
        B = -((M_dot(M_dot(trans(p), A), r_prime)[0][0]) / Y[0][0])

        # p' = r' + B*p
        for i in range(n):
            p[i][0] = r_prime[i][0] + B*p[i][0]

        # set r = r_prime, x = x_prime
        r = r_prime
        x = x_prime

        k += 1

    # return node potentials
    return x, inf_norm, two_norm

# dimensions for 1/4 section of the cable
dim_outer = 0.1
y_inner = 0.02
x_inner = 0.04
h = 0.02

A, b, n = fe.fe_grid_gen(dim_outer, y_inner, x_inner, h)

A_spd = M_dot(trans(A), A)
b_spd = M_dot(trans(A), b)
L = scipy.linalg.cholesky(A_spd, lower=True)

# Back substitution for solving L^T*x = y
x_cd = [[0.0] * 1 for i in range(n)]
for i in range(1, n + 1):
    x_cd[n - i][0] = b_spd[n - i][0] / L[n - i][n - i]
    for j in range(i + 1, n + 2):
        b_spd[n - j][0] = b_spd[n - j][0] - L[n - i][n - j] * x_cd[n - i][0]
print('x_CD = ', x_cd)

x_CG, inf, two_norm = CG(A, b, n)
for i in range(len(x_CG)):
    print(x_CG[i][0])