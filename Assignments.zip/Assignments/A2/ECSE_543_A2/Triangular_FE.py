# ESCE 543: Numerical Methods, Assignment 2, Q1 & 2
# Antonia Butler 260613935

# 1st order Triangular finite elements to solve Laplace for electrostatic potential
# Stiffness matrix needed for W = 1/2* U^T* S* U

import numpy as np

# helper functions:
# vector dot product:
def dot(A, B):
    n = len(A)  # (= len(B))
    dot = 0
    for i in range(n):
        dot += A[i]*B[i]
    return dot

# matrix dot product:
def M_dot(A, B):
    # A is n x m, B is p X q
    n = len(A)
    m = len(A[0])
    p = len(B)
    q = len(B[0])

    # m should = p
    if m != p:
        print("Matrices for dot product have invalid dimensions")
        return

    # result will be n x q
    dot_product = [[0] * q for i in range(n)]
    row, col = 0, 0
    while (row < n):
        for i in range(m):
            dot_product[row][col] += A[row][i] * B[i][col]
            round(dot_product[row][col], 3)
        col += 1
        if col == q:
            col = 0
            row += 1

    return dot_product

# transpose of a matrix:
def transpose(matrixA):
    n = len(matrixA)
    m = len(matrixA[0])
    AT = np.array([[0.0] * n for j in range(m)])
    for i in range(m):
        for j in range(n):
            AT[i][j] = matrixA[j][i]
    return AT

# element area
A = 0.0002

# grad(alpha) for each element:
grad_a1 = [[0, 50], [-50, -50], [50, 0]]
grad_a2 = [[50, 50], [-50, 0], [0, -50]]

# connectivity matrix:
C = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1], [1, 0, 0, 0], [0, 0, 1, 0]]

# stiffness matrix for each element:
S1 = [[0]*3 for i in range(3)]
S2 = [[0]*3 for i in range(3)]

# S[i][j] = A*grad_alpha[i]*grad_alpha[j]
for i in range (3):
    for j in range(3):
        S1[i][j] = dot(grad_a1[i], grad_a1[j])*A
        S2[i][j] = dot(grad_a2[i], grad_a2[j])*A

# disconnected S matrix:
S_dis = [[0]*6 for i in range(6)]

# block diagonal:
for i in range(3):
    for j in range (3):
        S_dis[i][j] = S1[i][j]
        S_dis[i+3][j+3] = S2[i][j]

# connected S matrix:
# S = C^T * S_dis * C
S = M_dot(transpose(C), S_dis)
S = M_dot(S, C)

print('S_con = ', S)

# obtain info (nodes, coords and node potentials) from the data file:
f = open('node_potentials.txt')
matrix = []
for line in f:
    array = line.split()
    matrix.append(array)

# Entries in matrix need to be converted string --> float
for i in range(len(matrix)):
    for j in range(len(matrix[i])):
        matrix[i][j] = float(matrix[i][j])

# the matrix has 4 columns (node number, x coord, y coord, node potential), and 32 rows (32 nodes)

# vector of energy in each finite mesh element: W = 1/2* U^T* S* U
W = []
i = 0
while len(W) < 23:      # 23 connected elements
    if (i+1)%(6) == 0:  # skip edge nodes
        i += 1
    U = [[matrix[i+6][3]], [matrix[i][3]], [matrix[i+1][3]], [matrix[i+7][3]]]      # connected element potential vector
    M = M_dot(M_dot(transpose(U), S), U)        # U^T* S* U, gives a 1 x 1 matrix
    W.append(M[0][0]/2)                         # W = 1/2* U^T* S* U
    i += 1

print('W = ', transpose([W]))

# total Energy in the system = sum of energy in each connected element
U_tot = 0
for i in range(len(W)):
    U_tot += W[i]
print(U_tot)

# Capacitance C = 2*E/V^2, V = 15 --> gives capacitance of 1/4 of the system (so we multiply by 4)
C = 4*2*U_tot/225*8.35      # multiply by E_0 --> gives value in pF
print(C, 'pF')
