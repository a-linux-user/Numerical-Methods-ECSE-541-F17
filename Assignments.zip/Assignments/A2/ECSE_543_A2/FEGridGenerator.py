# ESCE 543: Numerical Methods, Assignment 2, Q3
# Antonia Butler 260613935

# Generate matrix to represent Finite Element Grid for use in Choesky Decomposition method

import numpy as np

# transpose of a matrix:
def trans(matrixA):
    n = len(matrixA)
    m = len(matrixA[0])
    AT = np.array([[0.0] * n for j in range(m)])
    for i in range(m):
        for j in range(n):
            AT[i][j] = matrixA[j][i]
    return AT

def fe_grid_gen(dim_outer, y_inner, x_inner, h):
    # total number of nodes:
    n = pow(dim_outer/h + 1, 2)

    # omit edge nodes (fixed at 0V):
    n = n - 2*(dim_outer/h) - 1

    # omit nodes in center conductor:
    n = int(n - (y_inner/h*x_inner/h))
    print(n)

    # matrix should be n x n, n = number of free nodes:
    A = [[0.0]*n for i in range(n)]

    # offsets for some value of h:
    upd = int(dim_outer/h)

    # fill in A:
    for i in range(n):
        # all diagonal nodes have value -4 (for 5-pt finite elements):
        A[i][i] = -4

        # node to right:
        if i < n-1:
            A[i][i + 1] = 1

        # node to left:
        if i > 0:
            A[i][i - 1] = 1

        # node above:
        if i < n - upd:
            A[i][i+upd] = 1

        # node below:
        if i > upd + 1:
            if i > n - int((dim_outer-x_inner)/h) - 1:      # Neumann BCs...
                A[i][i-upd] = 2
            else:
                A[i][i-upd] = 1
        # Neumann BCs and symmetry: add 2x potential at edges within conductor
        if (i+1)%upd == 0:
            A[i][i-1] = 2
            A[i][i + 1] = 0
        if (i+1)%5 == 1:
            A[i][i-1] = 0

        # column vector of BCs: (for h = 0.02)
        # this can be generalized for arbitrary h later...
        b = [[0.0] * 1 for i in range(n)]
        b[17][0] = -15.0
        b[18][0] = -15.0
        b[19][0] = -15.0
        b[22][0] = -15.0

    return (A, b, n)

# note matrix is banded by 11 nodes for h = 0.02
# dimensions for 1/4 section of the cable
dim_outer = 0.1
y_inner = 0.02
x_inner = 0.04
h = 0.02

# A, b, n = fe_grid_gen(dim_outer, y_inner, x_inner, h)
# print("A = ", trans(trans(A)))
# print("b = ", trans(b))
#
