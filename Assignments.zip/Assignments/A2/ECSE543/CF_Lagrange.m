% ESCE 543: Numerical Methods, Assignment 3, Q1
% Antonia Butler 260613935

% Curve fitting & interpolation:
% Full-domain Lagrange Polynomials


% B values (T):
B = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9];
% H values (A/m):
H = [0.0, 14.7, 36.5, 71.7, 121.4, 197.4, 256.4, 348.7, 540.6, 1062.8, 2318.0, 4781.9, 8687.4, 13924.3, 22650.2];

% part (a) requires only the first 6 data points:
Ba = B(1:6);
Ha = H(1:6);

% number of points:
n = 6;

% part (b) requires also 6 ponts, but over a different range:
Bb = [0.0, 1.3, 1.4, 1.7, 1.8, 1.9];
Hb = [0.0, 540.6, 1062.8, 8687.4, 13924.3, 22650.2];
% scatter(Hb, Bb, 'o')
% xlabel('H (A/m)');
% ylabel('B (T)');

% Lagrangian L = F(x) / F(x_j)
% Each entry is an (n-1)-order polynomial: 
% --> represent by a matrix of coefficients:
L = zeros(n, n);
Fx = ones(1, n);

for j = 1:n
    syms f(x);      % function of symbolic variable x
    f = 1;
    for i = 1:n
        if i ~= j
            f = f*(x-Hb(i));
            Fx(j) = Fx(j)*(Hb(j)-Hb(i));
        end
    end
    c = coeffs(f, 'ALL');
    for i = 1:n
        L(j, i) = c(i)/Fx(j);
    end
end

% a vector of coefficeints for y(x) = SUM(a_j*L_j(x))
a = Bb;
x = [0: 0.05 : 22700];
L_plot =0;
for i = 1:6
    L_plot = L_plot + a(i)*(L(i,1)*x.^5 + L(i,2)*x.^4 + L(i,3)*x.^3 + L(i,4)*x.^2+L(i,5)*x + L(i,6));
end
plot(x, L_plot)
xlabel('H (A/m)');
ylabel('B (T)');


