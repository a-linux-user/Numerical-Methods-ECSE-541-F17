# ESCE 543: Numerical Methods, Assignment1, Q1
# Antonia Butler 260613935

# Q1) Write a program to solve the matrix equation Ax=b by Cholesky decomposition.
# A is a real, symmetric, positive-definite (SPD) matrix of order n.
import math
import numpy as np
import scipy
import scipy.linalg   # SciPy Linear Algebra Library

# define a few simple functions:
# matrix dot product:
def dot(A, B):
    # A is n x m, B is p X q
    n = len(A)
    m = len(A[0])
    p = len(B)
    q = len(B[0])

    # m should = p
    if m != p:
        print("Matrices for dot product have invalid dimensions")
        return

    # result will be n x q
    dot_product = [[0] * q for i in range(n)]
    row, col = 0, 0
    while (row < n):
        for i in range(m):
            dot_product[row][col] += A[row][i] * B[i][col]
            round(dot_product[row][col], 3)
        col += 1
        if col == q:
            col = 0
            row += 1

    return dot_product

# transpose of a matrix:
def transpose(matrixA):
    n = len(matrixA)
    m = len(matrixA[0])
    AT = np.array([[0.0] * n for j in range(m)])
    for i in range(m):
        for j in range(n):
            AT[i][j] = matrixA[j][i]
    return AT

# Cholesky Decomposition function:
# Using lookahead modification, and overwriting A with L, b with y:
def cholDec(A, b, N, banded):
    n = len(A)
    m = len(A[0])

    # full Chol decomp method:
    if not banded:
        for j in range(n):
            A[j][j] = math.sqrt(A[j][j])
            b[j][0] = (b[j][0] / A[j][j])
            for i in range(j + 1, n):
                A[i][j] = (A[i][j] / A[j][j])
                b[i][0] = b[i][0] - A[i][j] * b[j][0]
                for k in range(j+1, i+1):
                    A[i][k] = A[i][k]- A[i][j]*A[k][j]

        #  A = scipy.linalg.cholesky(A)
        # Back substitution for solving L^T*x = y
        # U = L^t: reverse indexes instead of creating U
        x = [[0.0]*1 for i in range(n)]
        for i in range(n-1, -1, -1):
            sumn = 0
            for j in range(i+1, n):
                sumn = A[j][i]*x[j][0]+sumn

            x[i][0] = (b[i][0] - sumn)/A[i][i]

    # method exploiting matrix bandedness:
    if banded:
        # Cholesky Decomposition using lookahead modification, and overwriting A with L
        # banded to reduce computation time

        # compute bandwidth:
        b_start, b_end = 0, 0
        for i in range(n):
            # n/2-th row since by this row we expect to see the full range of the bandwidth
            if A[int(n/2)][i] != 0 and b_start == 0:
                # 1st non-zero entry from left
                b_start = i
            if A[int(n/2)][n-i-1] != 0 and b_end == 0:
                # 1st non-zero entry from right
                b_end = n-i

        band = b_end - b_start
        print('band = ', band)
        bdiv2 = int(band/2)

        # include computation for outliers:
        # row indices (col is at m-1):
        out1 = 2*N -1
        out2 = 2*N*(N-1) + 1

        for j in range(n):
            A[j][j] = abs(math.sqrt(A[j][j]))
            b[j][0] = b[j][0] / A[j][j]
            if j == 0 :
                for i in range(bdiv2 + 1):
                    A[i][j] = A[i][j] / A[j][j]
                    b[i][0] = b[i][0] - A[i][j] * b[j][0]
                    for k in range(j + 1, i + 1):
                        A[i][k] = A[i][k] - A[i][j] * A[k][j]
            elif j < bdiv2 +1:
                for i in range(j-1, j + bdiv2 + 1):
                    A[i][j] = A[i][j] / A[j][j]
                    b[i][0] = b[i][0] - A[i][j] * b[j][0]
                    for k in range(j + 1, i + 1):
                        A[i][k] = A[i][k] - A[i][j] * A[k][j]
            elif j < n-bdiv2:
                for i in range(j - bdiv2, j + bdiv2):
                    A[i][j] = A[i][j] / A[j][j]
                    b[i][0] = b[i][0] - A[i][j] * b[j][0]
                    for k in range(j + 1, i + 1):
                        A[i][k] = A[i][k] - A[i][j] * A[k][j]

                # outliers are in this range
                if j == out1:
                    i = m-1
                    A[i][j] = A[i][j] / A[j][j]
                    b[i][0] = b[i][0] - A[i][j] * b[j][0]
                    for k in range(j + 1, i + 1):
                        A[i][k] = A[i][k] - A[i][j] * A[k][j]
                elif j == out2:
                    i = m - 1
                    A[i][j] = A[i][j] / A[j][j]
                    b[i][0] = b[i][0] - A[i][j] * b[j][0]
                    for k in range(j + 1, i + 1):
                        A[i][k] = A[i][k] - A[i][j] * A[k][j]

            else:
                for i in range(j - bdiv2, m):
                    A[i][j] = A[i][j] / A[j][j]
                    b[i][0] = b[i][0] - A[i][j] * b[j][0]
                    for k in range(j + 1, i + 1):
                        A[i][k] = A[i][k] - A[i][j] * A[k][j]

        # Back substitution for solving L^T*x = y
        x = [[0.0] * 1 for i in range(n)]
        for i in range(1, n + 1):
            x[n - i][0] = b[n - i][0] / A[n - i][n - i]
            for j in range(i + 1, n + 2):
                b[n - j][0] = b[n - j][0] - A[n - i][n - j] * x[n - i][0]

    return x


def node_voltages(matrix, N):
    # no. of rows:
    r = len(matrix)
    # no. of columns:
    c = len(matrix[0])

    # resistance vector
    R = matrix[0]
    # current source vector
    J = transpose([matrix[1]])
    # voltage source vector
    E = transpose([matrix[2]])
    # incidence matrix
    I = []
    for i in range(3, r):
        I.append(matrix[i])
    # admittance matrix (n x n)
    Y = [[0.0]*(c) for i in range(c)]
    for i in range(c):
        if R[i] == 0:
            Y[i][i] = 0
        else:
            Y[i][i] = 1/R[i]
            Y[i][i] = round(Y[i][i], 10)

    # Y is a diagonal matrix, whose entries are the branch admittances
    b = dot(I,(J - dot(Y, E)))

    A = dot(I, (dot(Y, transpose(I))))

    # solution: vector of node voltages
    v = cholDec(A, b, N, banded=True)

    return v

banded = False

# A = [[1, 0], [0, 1]]
# b = [[2.0], [5.0]]
# A = [[3, 1], [1, 1]]
# b = [[7], [3]]
# A = [[2, 1, 0], [-1, 3, -1], [0, -1, 4]]
# b = [[3], [2], [-5]]
#
# print("A = ", A)
# print("b = ", b)
# x = cholDec(A, b, banded)
#
# print("x = ", x)

f = open("sample5.txt", 'r')
matrix = []

# create matrix from file
# 1st row: branch resistances,
# 2nd row: branch current sources
# 3rd row: branch voltage sources
# subsequent rows: Incidence matrix

for line in f:
    array = line.split()
    matrix.append(array)

# Entries in matrix need to be converted string --> float
for i in range(len(matrix)):
    for j in range(len(matrix[i])):
        matrix[i][j] = float(matrix[i][j])

v = node_voltages(matrix, 0)
#print(v)
