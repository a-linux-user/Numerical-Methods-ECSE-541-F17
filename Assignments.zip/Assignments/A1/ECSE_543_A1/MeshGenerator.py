# ESCE 543: Numerical Methods, Assignment1
# Antonia Butler 260613935

# This program will take a number, N as input and generate a text file corresponding to the
# Linear Resistive Network consisting of an N x 2N mesh arrangement


def gen(N):
    # N must be >= 2:
    if N < 2:
        print("Argument invalid. N must be at least 2.")
        return

    # number of nodes:
    n = 2*pow(N, 2)
    # number of branches:
    b = 2*n - 3*N
    # Add another branch for test source so that resistance can be measured by R = V/I
    # This branch should be between the nodes where we want to measure the equivalent resistance (opposite corners)
    b += 1

    # generated grid will have n + 3 rows, and b columns
    matrix = [[0.0]*b for i in range(n+3)]

    # populate 1st row with branch resistances:
    for i in range(b):
        matrix[0][i] = 1000
        # test source branch also has a resistor of 1Kohm

    # populate 2nd row with branch current sources:
    # no current sources in the mesh, so no operation is required (all 0)

    # populate 3rd row with voltage sources:
    matrix[2][b-1] = 1  # test source of 1V

    # populate the remaining rows with reduced incidence matrix
    # current flow along horizontal branches:
    r, c = 0, 0
    for i in range (n-N):
        if i%(2*N-1) == 0 and i>0:  # every 2*N -1 nodes...
            r += 1          # skip one node (skip edge node)
            c += 2*N        # skip 2*N branches (skip vertical branches)
        matrix[3+i+r][i+c] = 1     # current leaving node [i+r], through branch [i+c]
        matrix[3+i+r+1][i+c] = -1  # current into node [i+r+1], through branch [i+c]

    # current flow in vertical branches:
    c = 2*N-1
    for i in range(n - 2*N):
        if i%(2*N) == 0 and i>0:     # every 2*N nodes...
            c += 2*N                 # skip 2*N branches (skip horizontal branches)
        matrix[3+i][i + c] = 1
        matrix[3+i+2*N][i+c] = -1

    # current flow in source branch:
    matrix[3+2*N-1][b-1] = -1
    matrix[3+n-2*N][b-1] = 1

    # make the node at the negative side of the voltage source ground:
    # delete the corresponding row in the incidence matrix
    del(matrix[3+n-2*N])

    return matrix

a = gen(2)
