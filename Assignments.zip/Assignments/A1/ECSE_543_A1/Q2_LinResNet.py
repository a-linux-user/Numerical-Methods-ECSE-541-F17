# ESCE 543: Numerical Methods, Assignment1, Q2
# Antonia Butler 260613935

import Chol_decomp as CH
import MeshGenerator as gen
from datetime import datetime   # for timing analysis


def r_eq(N):
    matrix = gen.gen(N)

    print(CH.transpose(CH.transpose(matrix)))

    voltages = CH.node_voltages(matrix, N)
    # Equivalent resistance R_eq = R*(V1 - V2)/(Vs(1 - V1 + V2)), by voltage division
    # V2 is grounded, so V2 = 0, and is not included in the vector of node voltages
    v1 = voltages[2*N-1][0]

    R_eq = 1000*v1/(1-v1)
    return R_eq

# N = [2, 3, 4, 5, 6, 7, 8, 9, 10]
# for N in range(2, 11):
#     startTime = datetime.now()
#     r = r_eq(N)
#     print('N = ', N, ', R = ', r, "   time: ", datetime.now() - startTime)

r = r_eq(2)
print(r)