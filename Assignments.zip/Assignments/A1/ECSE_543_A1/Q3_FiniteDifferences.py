# ESCE 543: Numerical Methods, Assignment1 Q3
# Antonia Butler 260613935

# find the electrical potential at points in a finite difference mesh between the conductors of a rectangular coax cable
# using 2 methods: Successive Over Relation (SOR) and Jacobian method


def fd_sor(h, w):
    # number of nodes:
    n = int(pow(0.1/ h + 1, 2))

    # create the potential mesh matrix:
    U = [0]*n

    # relative positioning offsets:
    # node above/below:
    upd = int(0.1/h) + 1
    # node left/right is just j +- 1

    # set potential at fixed nodes (15V):
    row = 0
    for i in range (int(0.02/h)+1):
        for j in range(int(0.04//h)+1):
            U[n -(row*(int(0.1/h)+1) + j)-1] = 15
        row += 1

    # measure of residual, for stopping condition.
    res = 1         # must be initiated to non-zero value greater than 10^-5
    itr = 0

    while abs(res) > 1e-5:
        itr += 1
        res_new = []

        # fill in grid potentials:
        # U' = (1-w)*U + w/4*(U'(down) + U'(left) + U(up) + U(right))

        for i in range(n):
            # omit fixed nodes:
            if U[i] == 15:
                continue

            if i < int(0.1/h)+1 or i%(int(0.1/h)+1) == 0:
                # outer boundary nodes:
                U[i] = 0

            elif i%(int(0.1/h) + 1) == (0.1/h):
                # inner bounds: Nuemann BCs along right edge
                U[i] = (1 - w) * U[i] + w / 4 * (U[i - upd] + 2*U[i - 1] + U[i + upd])

            elif i > (n - int(0.1/h) - 1):
                # inner bounds: Neumann BCs along upper edge
                U[i] = (1 - w) * U[i] + w / 4 * (2*U[i - upd] + U[i - 1] + U[i + 1])

            else:
                # center nodes:
                U[i] = (1-w)*U[i] + w/4*(U[i-upd]+ U[i-1] + U[i+upd] + U[i + 1])

                # update residual at center nodes:
                res_new.append(U[i-upd] + U[i-1] + U[i+upd] + U[i+1] - 4*U[i])

        for i in range(len(res_new)):
            if i == 0:
                res = res_new[i]
            if abs(res_new[i]) > abs(res):
                res = res_new[i]      # choose largest residual per iteration

    return U, itr, res

def fd_jacobi(h):
    # number of nodes:
    n = int(pow(0.1 / h + 1, 2))
    # create the potential mesh matrix:
    U = [0] * n
    # relative positioning offsets:
    upd = int(0.1 / h) + 1          # node above/below

    # set potential at fixed nodes (15V):
    row = 0
    for i in range(int(0.02 / h) + 1):
        for j in range(int(0.04 // h) + 1):
            U[n - (row * (int(0.1 / h) + 1) + j) - 1] = 15
        row += 1

    # measure of residual, for stopping condition.
    res = 1      # must be initiated to non-zero value greater than 10^-5
    itr = 0
    res_prev = 0
    while abs(res - res_prev) > 1e-5:
        itr += 1
        res_new = []
        # fill in grid potentials:
        # U' = 1/4*(U'(down) + U'(left) + U(up) + U(right))
        U_new = [0.0] * n
        for i in range(n):
            # fixed nodes:
            if U[i] == 15:
                U_new[i] = 15
            # outer boundary nodes:
            elif i < int(0.1 / h) + 1 or i % (int(0.1 / h) + 1) == 0:
                U_new[i] = 0
            # inner bounds: Neumann BCs along right edge
            elif i % (int(0.1 / h) + 1) == (0.1 / h):
                U_new[i] = 1 / 4 * (U[i - upd] + 2 * U[i - 1] + U[i + upd])
            # inner bounds: Neumann BCs along upper edge
            elif i > (n - int(0.1 / h) - 1):
                U_new[i] = 1 / 4 * (2 * U[i - upd] + U[i - 1] + U[i + 1])
            # center nodes:
            else:
                U_new[i] = 1/4*(U[i - upd] + U[i - 1] + U[i + upd] + U[i + 1])
                # update residual at center nodes:
                res_new.append(U_new[i-upd] + U_new[i-1] + U_new[i+upd] + U_new[i+1] - 4*U_new[i])

        if itr > 1:
            res_prev = res

        for i in range(len(res_new)):
            if itr == 1:
                res = res_new[0]
            if abs(res_new[i]) > abs(res):
                res = res_new[i]  # choose largest node residual per iteration
        #update U:
        U = U_new

    return U, itr


h = 0.02
w = 1.3
# U, itr, res = fd_sor(h, w)
# print('itr = ', itr)
# print('U = ', U)
# print('res = ', res)

# w_vec = [1.1, 1.15, 1.2, 1.25, 1.3, 1.35, 1.4, 1.55, 1.7, 1.9]
# for w in range(110, 200, 2):
#     U, itr, res = fd_sor(h, w/100)
#     print('w = ', w, 'itr = ', itr, 'res = ', res)
#     print(U[15])      # potential at (0.06, 0.04) for h = 0.02

# h_var = [0.02, 0.01, 0.005, 0.0025, 0.00125]
# for h in h_var:
#     U, itr, res = fd_sor(h, 1.3)
#     print('h = ', h, 'itr = ', itr)
#     # U(0.06, 0.04):
#     if h == 0.02:
#         print(U[15])
#     elif h == 0.01:
#         print(U[51])
#     elif h == 0.005:
#         print(U[160])
#     elif h == 0.0025:
#         print(U[681])
#     elif h == 0.00125:
#         print(U[2641])

U, itr = fd_jacobi(0.0025)
print(U)
print(itr, U[681])
print(itr, U[680])
print(itr, U[682])